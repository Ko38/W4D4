require_relative "card.rb"

class Hand
  def initialize 
    @cards = Array.new(5)
  end

end