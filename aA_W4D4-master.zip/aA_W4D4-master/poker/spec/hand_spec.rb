require "hand"

describe Hand do


end